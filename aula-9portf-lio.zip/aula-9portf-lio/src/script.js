function mudaTema() {
  document.body.classList.toggle("dark");
}
